# Enterprise Import Guide

## Architecture

1. Create the local behavior model with Ollama.
2. Import the corpus bundle into Open WebUI Knowledge.
3. Attach the Knowledge base to the model.
4. Optionally generate local embeddings for script-based retrieval.

## Correct claim boundary

- Correct: The Modelfile configures Wa! behavior.
- Correct: The RAG bundle supplies searchable Wa! knowledge.
- Incorrect: The corpus has been baked into model weights.

## Commands

```bash
ollama pull llama3.2
ollama create wa-cha-local -f 01_ollama/Modelfile
ollama run wa-cha-local
```

# Fine-tuning Later, Not Now

This package prepares a local behavior kernel and a retrieval corpus. It does not fine-tune model weights.

Fine-tuning should only be considered after you have:

- thousands of clean input -> ideal output examples,
- consistent formatting,
- removed duplicated or private material,
- evaluation prompts with expected outputs,
- a clear reason retrieval is insufficient.

Until then, Modelfile + RAG is the more efficient and safer architecture.

# Security and Privacy Notes

- This package is designed for local use.
- No external paid APIs are required by the included scripts.
- Do not place API keys, passwords, tokens, private keys, or secrets in the corpus files.
- Before importing a full ChatGPT export, inspect it for personal data you do not want indexed.
- `08_user_drop_zone/` is intentionally excluded from generated embeddings until you run the merge/normalization scripts yourself.
- No fine-tuning was performed.

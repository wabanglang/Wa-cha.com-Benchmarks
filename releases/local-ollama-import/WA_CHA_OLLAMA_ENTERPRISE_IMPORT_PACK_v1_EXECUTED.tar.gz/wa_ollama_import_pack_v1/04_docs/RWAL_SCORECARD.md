# RWAL Scorecard

RWAL:BINARY_SCORE = 1

## Real

The package folder, Modelfile, corpus JSONL files, scripts, source inventory, checksums, and archives are generated as actual local files.

## World-bound

The import path matches the operational split used by Ollama and RAG frontends: Modelfile for model behavior and Knowledge/RAG files for searchable corpus memory.

## Actual

JSON/JSONL validation, manifest generation, checksums, and archive integrity checks are executed in the build environment.

## Literal

The package does not claim inaccessible data was included. It does not claim fine-tuning or weight-level corpus ingestion.

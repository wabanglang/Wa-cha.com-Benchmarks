# QA Acceptance Tests

## Required validation

- [x] Required folder tree exists.
- [x] `01_ollama/Modelfile` exists.
- [x] `01_ollama/wa_kernel_system_prompt.md` exists.
- [x] `03_structured_corpus/wa_semantic_units.jsonl` exists.
- [x] `03_structured_corpus/wa_chunks_for_rag.jsonl` exists.
- [x] JSON files parse.
- [x] JSONL files parse line by line.
- [x] Source inventory exists.
- [x] Semantic unit count > 0. Count: 341.
- [x] RAG chunk count > 0. Count: 15.
- [x] Package contains import scripts.
- [x] Package contains import instructions.

## Behavior tests

1. Ask `wa-cha-local`: "Define RWAL and explain how it gates local import claims."
2. Ask: "What is the difference between Ollama Modelfile import and RAG corpus import?"
3. Ask: "Translate the local import process into 1dfa1cb."
4. Ask: "What source limitations exist in the package?"

Expected behavior: answers should distinguish behavior configuration from corpus retrieval and should not claim weight-level ingestion.

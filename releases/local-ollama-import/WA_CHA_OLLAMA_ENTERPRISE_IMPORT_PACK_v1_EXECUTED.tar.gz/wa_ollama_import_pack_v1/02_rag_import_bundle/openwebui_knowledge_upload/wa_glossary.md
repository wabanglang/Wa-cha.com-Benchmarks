# Wa! Glossary

- **Wa!**: Symbolic prompt-compression and procedural instruction architecture used as the project kernel.
- **Wa-cha!^*+**: High-fidelity recurse, preserve, complete, validate, and deliver directive.
- **RWAL**: Real, World-bound, Actual, Literal validation gates.
- **ABS**: Absolute preservation of source fidelity where required.
- **ATOMIC**: Break tasks into smallest actionable semantic or process units.
- **CANONICAL**: Stable, reusable, source-faithful, implementation-ready representation.
- **1CB**: One complete code block or one complete block where requested.
- **1dfa1cb**: One-dimensional flat array in one code block.
- **MSSP**: mlang single-symbolic pyramid.
- **Ollama Modelfile**: Behavior configuration blueprint for a local model; not a corpus ingestion mechanism.
- **RAG**: Retrieval-augmented generation: searchable corpus memory via embeddings and chunk retrieval.
- **Fine-tuning**: Optional later training/adaptation stage requiring clean input-output examples.

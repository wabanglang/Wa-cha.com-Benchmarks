# Upload this folder to Open WebUI Knowledge

Create a Knowledge base named `WA_EVERYTHING_RAG`, then upload or sync this entire folder.

Files here are text-first and RAG-ready.

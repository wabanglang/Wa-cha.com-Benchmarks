# WA_CHA_OLLAMA_ENTERPRISE_IMPORT_PACK_v1

AUTHOR: Douglas W. T. Jackson
⠠⠠⠁⠥⠞⠓⠕⠗⠀⠒⠀⠠⠙⠕⠥⠛⠇⠁⠎⠀⠠⠺⠲⠀⠠⠞⠲⠂⠀⠠⠚⠁⠉⠅⠎⠕⠝⠀⠁⠇⠇⠀⠗⠊⠛⠓⠞⠎⠀⠗⠑⠎⠑⠗⠧⠑⠙⠲

## Purpose

This package creates a local Wa! assistant architecture using:

- **Ollama Modelfile** as the behavior kernel.
- **Open WebUI / RAG Knowledge files** as the searchable Wa! corpus memory.
- **Local Ollama embeddings** as an optional retrieval index.

It does **not** claim that files have been baked into model weights. No fine-tuning was performed.

## Package map

```text
01_ollama/                  Ollama Modelfile and Wa! system prompt
02_rag_import_bundle/       Open WebUI Knowledge upload bundle
03_structured_corpus/       JSONL, Markdown, glossary, goal map, Wa! array
04_docs/                    Import guide, QA tests, RWAL, security notes
05_raw_sources/             Accessible raw source copies
06_eval/                    Evaluation prompts and behavior tests
07_openwebui/               Open WebUI setup notes
08_user_drop_zone/          Place future ChatGPT export ZIPs here
09_generated_embeddings/    Local embedding outputs go here
scripts/                    Local install, validation, embedding, query scripts
```

## What Ollama imports directly

Ollama imports the **Modelfile** in `01_ollama/`. That configures model behavior, system instructions, parameters, and base model selection.

## What RAG imports

RAG imports the files under:

```text
02_rag_import_bundle/openwebui_knowledge_upload/
```

These files are the searchable Wa! corpus memory.

## Why Modelfile + RAG

A Modelfile controls behavior. A RAG/Knowledge corpus supplies retrieved source context. This keeps the model local, avoids fake claims of weight-level ingestion, and supports large document collections without exceeding context windows.

## Quick start

```bash
cd wa_ollama_import_pack_v1
bash scripts/install_wa_ollama.sh
```

## Manual Ollama commands

```bash
ollama pull llama3.2
ollama create wa-cha-local -f 01_ollama/Modelfile
ollama run wa-cha-local
```

## Open WebUI Knowledge import

1. Open Open WebUI.
2. Go to Workspace -> Knowledge.
3. Create a Knowledge base named `WA_EVERYTHING_RAG`.
4. Upload or sync this folder:

```text
02_rag_import_bundle/openwebui_knowledge_upload/
```

5. Attach `WA_EVERYTHING_RAG` to the `wa-cha-local` model.

## Embedding generation

```bash
python3 scripts/embed_chunks_with_ollama.py \
  --model embeddinggemma \
  --input 03_structured_corpus/wa_chunks_for_rag.jsonl \
  --output 09_generated_embeddings/wa_embeddings.jsonl
```

## Local query

```bash
python3 scripts/rag_query_local.py \
  --embeddings 09_generated_embeddings/wa_embeddings.jsonl \
  --query "What is RWAL?"
```

## Build status

- Semantic units: 341
- RAG chunks: 15
- Source inventory entries: 9
- RWAL:BINARY_SCORE: 1

## Known limitations

- This package contains accessible uploaded/source files only.
- It does not include inaccessible full ChatGPT account export data unless you add that export to `08_user_drop_zone/` and run the normalization script.
- No fine-tuning, LoRA training, or adapter creation was performed.

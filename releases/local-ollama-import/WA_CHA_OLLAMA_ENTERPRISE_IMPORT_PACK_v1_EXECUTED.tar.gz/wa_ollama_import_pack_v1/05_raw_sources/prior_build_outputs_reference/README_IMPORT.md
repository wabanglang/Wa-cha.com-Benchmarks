# WA-CHA OLLAMA ENTERPRISE IMPORT PACK v1

Generated: 2026-06-30 America/Los_Angeles
Package purpose: create a local `wa-cha-local` Ollama behavior model and import the WA! corpus into a retrieval-ready local knowledge layer.

## What this package is

This is an enterprise-ready local import pack containing:

- Ollama Modelfile for `wa-cha-local`
- WA!/Wa-cha/RWAL kernel system prompt
- normalized source corpus
- RAG-ready JSONL chunks
- Open WebUI Knowledge upload bundle
- local embedding/query scripts using the Ollama API
- QA / RWAL acceptance tests
- source inventory and SHA-256 manifest

## What this package is not

This is not a fine-tuned model weight file. It does not bake WA! Everything into model weights. It uses the correct local architecture:

```text
Ollama Modelfile = WA! behavior kernel
RAG / Knowledge base = WA! Everything corpus
Embeddings = local semantic search layer
Fine-tuning = later, only after clean example pairs
```

## Fast install

### macOS / Linux

```bash
cd wa_ollama_import_pack_v1
bash scripts/install_wa_ollama.sh
```

### Windows PowerShell

```powershell
cd wa_ollama_import_pack_v1
powershell -ExecutionPolicy Bypass -File scripts/install_wa_ollama.ps1
```

## Manual Ollama import

```bash
cd 01_ollama
ollama pull llama3.2
ollama create wa-cha-local -f Modelfile
ollama run wa-cha-local
```

## Knowledge import

Open WebUI path:

1. Workspace -> Knowledge -> New Knowledge
2. Name: `WA_EVERYTHING_RAG`
3. Upload or sync folder: `02_rag_import_bundle/openwebui_knowledge_upload/`
4. Attach that Knowledge base to the `wa-cha-local` model.

## Local RAG script path

```bash
python3 scripts/validate_pack.py
python3 scripts/embed_chunks_with_ollama.py --model embeddinggemma --input 03_structured_corpus/wa_chunks_for_rag.jsonl --output 09_generated_embeddings/wa_embeddings.jsonl
python3 scripts/rag_query_local.py --embeddings 09_generated_embeddings/wa_embeddings.jsonl --query "What is RWAL?"
```

## Source coverage notice

This package includes all WA! materials available in the current working session:

- `wa_transcript_professional_array.txt`
- `wa_conversation_professional_array.txt`
- `AI Semantic Extraction Process.pdf`
- PDF-extracted text
- accessible WA!/Wa-cha project context compiled into `wa_accessible_project_context.md`

For full account-wide coverage, place the official ChatGPT export ZIP in `08_user_drop_zone/` and run:

```bash
python3 scripts/build_from_chatgpt_export.py --export_zip 08_user_drop_zone/chatgpt_export.zip --out 03_structured_corpus/chatgpt_export_units.jsonl
```

## RWAL status

```text
RWAL:BINARY_SCORE = 1
R = real files generated
W = local-system import path included
A = actual ZIP package produced
L = literal: RAG import, not weight fine-tune
```

AUTHOR: Douglas W. T. Jackson
Braille: ⠠⠠⠁⠥⠞⠓⠕⠗⠀⠒⠀⠠⠙⠕⠥⠛⠇⠁⠎⠀⠠⠺⠲⠀⠠⠞⠲⠂⠀⠠⠚⠁⠉⠅⠎⠕⠝⠀⠁⠇⠇⠀⠗⠊⠛⠓⠞⠎⠀⠗⠑⠎⠑⠗⠧⠑⠙⠲

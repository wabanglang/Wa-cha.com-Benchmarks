# Generated Embeddings

Run `scripts/embed_chunks_with_ollama.py` to write `wa_embeddings.jsonl` here.

# User Drop Zone

Place future ChatGPT export ZIPs, docs, notes, or artifacts here, then run `scripts/merge_user_drop_zone.py` or `scripts/normalize_chatgpt_export.py`.

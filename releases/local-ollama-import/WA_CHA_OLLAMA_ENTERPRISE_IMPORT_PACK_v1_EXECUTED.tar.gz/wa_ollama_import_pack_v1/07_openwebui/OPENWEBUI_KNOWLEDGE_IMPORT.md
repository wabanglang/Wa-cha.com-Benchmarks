# Open WebUI Knowledge Import

1. Open Workspace -> Knowledge.
2. Create `WA_EVERYTHING_RAG`.
3. Upload or sync: `02_rag_import_bundle/openwebui_knowledge_upload/`.
4. Attach the Knowledge base to `wa-cha-local` under Workspace -> Models -> Edit.
5. Ask the model to use retrieved source chunks when answering Wa! corpus questions.

For large future corpora, prefer directory sync or the official sync workflow rather than manual file-by-file upload.

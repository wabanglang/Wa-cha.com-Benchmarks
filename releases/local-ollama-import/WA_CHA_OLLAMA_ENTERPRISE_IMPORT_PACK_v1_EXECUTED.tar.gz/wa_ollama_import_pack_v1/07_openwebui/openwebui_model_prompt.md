Use the `WA_EVERYTHING_RAG` Knowledge base for Wa! project history, definitions, source-bound constraints, and semantic unit retrieval. Do not invent source history when retrieval is unavailable.

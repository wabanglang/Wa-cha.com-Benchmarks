#!/usr/bin/env python3
import json, sys, zipfile
from pathlib import Path
root = Path(__file__).resolve().parents[1]
required = [
  'README_IMPORT.md','SOURCE_INVENTORY.json','PACKAGE_METADATA.json','MANIFEST.txt','CHECKSUMS.sha256',
  '01_ollama/Modelfile','01_ollama/wa_kernel_system_prompt.md',
  '03_structured_corpus/wa_semantic_units.jsonl','03_structured_corpus/wa_chunks_for_rag.jsonl',
  '04_docs/QA_ACCEPTANCE_TESTS.md','04_docs/RWAL_SCORECARD.md'
]
missing=[p for p in required if not (root/p).exists()]
if missing:
  print('MISSING', missing); sys.exit(1)
for p in root.rglob('*.json'):
  json.loads(p.read_text(encoding='utf-8'))
for p in root.rglob('*.jsonl'):
  for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
    if line.strip(): json.loads(line)
units=sum(1 for _ in (root/'03_structured_corpus/wa_semantic_units.jsonl').open(encoding='utf-8'))
chunks=sum(1 for _ in (root/'03_structured_corpus/wa_chunks_for_rag.jsonl').open(encoding='utf-8'))
print({'status':'pass','semantic_units':units,'rag_chunks':chunks,'root':str(root)})

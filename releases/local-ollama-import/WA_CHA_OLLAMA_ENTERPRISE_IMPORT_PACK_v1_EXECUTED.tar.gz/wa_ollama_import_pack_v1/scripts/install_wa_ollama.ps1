$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)
if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
  Write-Error "ollama is not installed or not on PATH. Install Ollama first: https://ollama.com/download"
}
ollama pull llama3.2
ollama create wa-cha-local -f 01_ollama/Modelfile
Write-Host "Created wa-cha-local. Run: ollama run wa-cha-local"

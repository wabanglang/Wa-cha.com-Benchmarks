#!/usr/bin/env python3
import argparse, json, urllib.request, urllib.error, sys
from pathlib import Path

def post_embed(model, inputs):
    data=json.dumps({'model':model,'input':inputs}).encode('utf-8')
    req=urllib.request.Request('http://localhost:11434/api/embed', data=data, headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read().decode('utf-8'))['embeddings']

ap=argparse.ArgumentParser()
ap.add_argument('--model', default='embeddinggemma')
ap.add_argument('--input', required=True)
ap.add_argument('--output', required=True)
ap.add_argument('--batch-size', type=int, default=16)
args=ap.parse_args()
chunks=[json.loads(line) for line in Path(args.input).read_text(encoding='utf-8').splitlines() if line.strip()]
out=Path(args.output); out.parent.mkdir(parents=True, exist_ok=True)
with out.open('w', encoding='utf-8') as f:
    for i in range(0,len(chunks),args.batch_size):
        batch=chunks[i:i+args.batch_size]
        texts=[c['text'] for c in batch]
        embs=post_embed(args.model, texts)
        for c,e in zip(batch, embs):
            f.write(json.dumps({'chunk_id':c['chunk_id'],'embedding_model':args.model,'embedding':e,'text':c['text'],'metadata':{k:v for k,v in c.items() if k!='text'}}, ensure_ascii=False)+'
')
        print(f'embedded {min(i+args.batch_size,len(chunks))}/{len(chunks)}')
print(f'wrote {out}')

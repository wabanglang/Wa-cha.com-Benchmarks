#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
paths = sorted(str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name not in {'MANIFEST.txt'})
(root/'MANIFEST.txt').write_text('
'.join(paths)+'
', encoding='utf-8')
print(f'wrote {len(paths)} entries')

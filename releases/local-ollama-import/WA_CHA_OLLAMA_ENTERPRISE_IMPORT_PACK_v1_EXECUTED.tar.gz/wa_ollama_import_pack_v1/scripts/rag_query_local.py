#!/usr/bin/env python3
import argparse, json, math, urllib.request
from pathlib import Path

def embed(model, text):
    data=json.dumps({'model':model,'input':text}).encode('utf-8')
    req=urllib.request.Request('http://localhost:11434/api/embed', data=data, headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read().decode('utf-8'))['embeddings'][0]

def dot(a,b): return sum(x*y for x,y in zip(a,b))

ap=argparse.ArgumentParser()
ap.add_argument('--embeddings', required=True)
ap.add_argument('--query', required=True)
ap.add_argument('--model', default=None)
ap.add_argument('--top-k', type=int, default=5)
args=ap.parse_args()
rows=[json.loads(line) for line in Path(args.embeddings).read_text(encoding='utf-8').splitlines() if line.strip()]
model=args.model or rows[0].get('embedding_model','embeddinggemma')
q=embed(model,args.query)
scored=sorted(((dot(q,r['embedding']),r) for r in rows), reverse=True, key=lambda x:x[0])[:args.top_k]
for score,row in scored:
    print('='*80)
    print(f"score={score:.4f} chunk_id={row['chunk_id']}")
    print(row['text'][:3000])

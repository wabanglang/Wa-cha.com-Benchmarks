#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
drop=root/'08_user_drop_zone'
out=root/'03_structured_corpus'/'user_drop_zone_merged.txt'
texts=[]
for p in sorted(drop.rglob('*')):
    if p.is_file() and p.suffix.lower() in {'.txt','.md','.json','.jsonl'}:
        texts.append(f"

===== {p.relative_to(root)} =====
"+p.read_text(encoding='utf-8', errors='ignore'))
out.write_text('
'.join(texts), encoding='utf-8')
print(f'wrote {out} from {len(texts)} files')

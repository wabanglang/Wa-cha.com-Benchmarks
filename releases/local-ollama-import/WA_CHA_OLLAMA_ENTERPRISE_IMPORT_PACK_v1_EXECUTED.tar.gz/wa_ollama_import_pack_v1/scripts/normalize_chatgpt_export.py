#!/usr/bin/env python3
import argparse, json, zipfile
from pathlib import Path
ap=argparse.ArgumentParser(description='Normalize a ChatGPT export ZIP into text files for later Wa! corpus merge.')
ap.add_argument('export_zip')
ap.add_argument('--out', default='08_user_drop_zone/normalized_chatgpt_export')
args=ap.parse_args()
out=Path(args.out); out.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(args.export_zip) as z:
    names=z.namelist()
    for name in names:
        if name.endswith('conversations.json'):
            data=json.loads(z.read(name).decode('utf-8'))
            (out/'conversations.pretty.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
            lines=[]
            for conv in data:
                title=conv.get('title','untitled')
                lines.append(f"# Conversation: {title}
")
                mapping=conv.get('mapping',{})
                for node in mapping.values():
                    msg=node.get('message') or {}
                    role=(msg.get('author') or {}).get('role')
                    parts=((msg.get('content') or {}).get('parts') or [])
                    if parts:
                        lines.append(f"## {role}
" + '
'.join(str(p) for p in parts) + '
')
            (out/'conversations.md').write_text('
'.join(lines), encoding='utf-8')
print(f'wrote normalized export to {out}')

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v ollama >/dev/null 2>&1; then
  echo "ERROR: ollama is not installed or not on PATH. Install Ollama first: https://ollama.com/download" >&2
  exit 1
fi
ollama pull llama3.2
ollama create wa-cha-local -f 01_ollama/Modelfile
printf '
Created wa-cha-local. Run:
  ollama run wa-cha-local

'
